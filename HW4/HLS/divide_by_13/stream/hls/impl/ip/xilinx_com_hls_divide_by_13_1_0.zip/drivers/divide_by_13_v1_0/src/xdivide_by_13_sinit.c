// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xdivide_by_13.h"

extern XDivide_by_13_Config XDivide_by_13_ConfigTable[];

#ifdef SDT
XDivide_by_13_Config *XDivide_by_13_LookupConfig(UINTPTR BaseAddress) {
	XDivide_by_13_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XDivide_by_13_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XDivide_by_13_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XDivide_by_13_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDivide_by_13_Initialize(XDivide_by_13 *InstancePtr, UINTPTR BaseAddress) {
	XDivide_by_13_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDivide_by_13_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDivide_by_13_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XDivide_by_13_Config *XDivide_by_13_LookupConfig(u16 DeviceId) {
	XDivide_by_13_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XDIVIDE_BY_13_NUM_INSTANCES; Index++) {
		if (XDivide_by_13_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XDivide_by_13_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XDivide_by_13_Initialize(XDivide_by_13 *InstancePtr, u16 DeviceId) {
	XDivide_by_13_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XDivide_by_13_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XDivide_by_13_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

